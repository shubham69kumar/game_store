var express = require("express")
var bodyParser = require("body-parser")
var mongoose = require("mongoose")
const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')
const router = express.Router()




mongoose.connect("mongodb://localhost:27017/game_store",{ useNewUrlParser: true ,  useUnifiedTopology: true, useFindAndModify: false, useCreateIndex: true },(error)=>{
});
 
var db = mongoose.connection;

db.on('error',()=>console.log("Error in Connecting to Database"));
db.once('open',()=>console.log("Connected to Database"))


const app = express()

app.use(bodyParser.json())
app.use(express.static('public'))
app.use(bodyParser.urlencoded({
    extended:true
}))

app.post("/sign_up",(req,res)=>{
	bcrypt.hash(req.body.password,10,function(err,hashedPass){
		if(err){
			throw err;
		}
    var name = req.body.name;
    var email = req.body.email;
    var password = hashedPass;

    var data = {
        "name": name,
        "email" : email,
        "password" : password
    }

    db.collection('users').insertOne(data,(err,collection)=>{
        if(err){
            throw err;
        }
        console.log("Record Inserted Successfully");
    });

    return res.redirect('index.html')
    })

})

app.post("/login",(req,res)=>{
    var username = req.body.username;
    var password = req.body.password;
    db.collection('users').findOne({$or:[{email:req.body.username},{name:req.body.username}]})
    .then(user => {
        if(user){
            bcrypt.compare(password,user.password,function(err,result){
                if(err){
                    res.json({
                        error:err
                    })
                }
                if(result){
                    let token = jwt.sign({name:user.name},'verySecretValue',{expiresIn:'1h'})
                    return res.redirect('home.html')
                }else{
                    res.json({
                        message:'password does not matched !!'
                    })
                }
            })
        }else{
            res.json({
                message:'no user found !!'
            })
        }
    })
 
})


app.get('/logout',function(req,res){
  try{
    res.clearCookie("jwt");
    console.log("logout Successfully")
    return res.redirect('index.html')
  } catch(error){
    res.status(500).send(error);
  }
});







app.get("/",(req,res)=>{
    res.set({
        "Allow-access-Allow-Origin": '*'
    })
    return res.redirect('index.html');
}).listen(3000);


console.log("Listening on PORT 3000");